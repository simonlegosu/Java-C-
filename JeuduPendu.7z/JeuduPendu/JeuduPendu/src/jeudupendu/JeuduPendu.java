
package jeudupendu;
import java.awt.*;
import java.awt.event.*;
import java.awt.Component.*;
import javax.swing.*;
import java.text.*;
import java.util.*;

public class JeuduPendu {
    
    
    public static void main(String[] args) 
    {
        accueilFrame acc = new accueilFrame();
        acc.setVisible(true);
    }
    
}


package aubergefdl;
import java.awt.*;
import java.awt.event.*;
import java.awt.Component.*;
import javax.swing.*;
import java.text.*;
import java.util.*;

//a fixer = id unique pour chaque employer, ne pas autoriser les doublons

public class AubergeFDL 
{   

    
    public static void main(String[] args) 
    {
        mainFrame mF = new mainFrame();
        mF.setVisible(true);
    }
}
    


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuichetClasse
{
    class Epargne : Compte
    {
        public const double tauxInteret = 1;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuichetClasse
{
    public class Cheque : Compte
    {
       public const double fraisPaiementFacture = 1.25;
       public const double montantFactureMaximum = 10000;      
    }
}
